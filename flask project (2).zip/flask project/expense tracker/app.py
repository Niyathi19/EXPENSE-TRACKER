from flask import (
    Flask, render_template, redirect,
    url_for, request, flash
)
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin,
    login_user, login_required,
    logout_user, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func
from datetime import datetime, date

# -------------------------------------------------
# APP CONFIG
# -------------------------------------------------
app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-secret-key"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///expense.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

login_manager = LoginManager(app)
login_manager.login_view = "login"

# -------------------------------------------------
# MODELS
# -------------------------------------------------
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    monthly_budget = db.Column(db.Float, default=0)

class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(100), nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)

# -------------------------------------------------
# LOGIN MANAGER
# -------------------------------------------------
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# -------------------------------------------------
# AUTH ROUTES
# -------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = generate_password_hash(request.form["password"])

        if User.query.filter_by(username=username).first():
            flash("Username already exists", "danger")
            return redirect(url_for("register"))

        user = User(username=username, password=password)
        db.session.add(user)
        db.session.commit()

        flash("Registration successful. Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(username=request.form["username"]).first()

        if user and check_password_hash(user.password, request.form["password"]):
            login_user(user)
            next_page = request.args.get("next")
            return redirect(next_page or url_for("dashboard"))

        flash("Invalid username or password", "danger")

    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

# -------------------------------------------------
# HOME
# -------------------------------------------------
@app.route("/")
@login_required
def home():
    return redirect(url_for("dashboard"))

# -------------------------------------------------
# DASHBOARD
# -------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    today = date.today()

    user_expenses = Expense.query.filter_by(user_id=current_user.id)

    # Totals
    monthly_total = user_expenses.filter(
        func.extract("month", Expense.date) == today.month,
        func.extract("year", Expense.date) == today.year
    ).with_entities(func.sum(Expense.amount)).scalar() or 0

    yearly_total = user_expenses.filter(
        func.extract("year", Expense.date) == today.year
    ).with_entities(func.sum(Expense.amount)).scalar() or 0

    # Budget logic
    budget = current_user.monthly_budget
    budget_exceeded = budget > 0 and monthly_total > budget

    # Category chart
    category_data = user_expenses.with_entities(
        Expense.category,
        func.sum(Expense.amount)
    ).group_by(Expense.category).all()

    categories = [c[0] for c in category_data]
    category_amounts = [float(c[1]) for c in category_data]

    # Daily chart
    daily_data = user_expenses.with_entities(
        func.date(Expense.date),
        func.sum(Expense.amount)
    ).group_by(func.date(Expense.date)).all()

    dates = [d[0] for d in daily_data]
    daily_amounts = [float(d[1]) for d in daily_data]

    # Top categories
    top_categories = user_expenses.with_entities(
        Expense.category,
        func.sum(Expense.amount)
    ).group_by(Expense.category)\
     .order_by(func.sum(Expense.amount).desc())\
     .limit(5).all()

    return render_template(
        "dashboard.html",
        monthly_total=monthly_total,
        yearly_total=yearly_total,
        categories=categories,
        category_amounts=category_amounts,
        dates=dates,
        daily_amounts=daily_amounts,
        top_categories=top_categories,
        budget=budget,
        budget_exceeded=budget_exceeded
    )

# -------------------------------------------------
# ADD EXPENSE
# -------------------------------------------------
@app.route("/add", methods=["GET", "POST"])
@login_required
def add_expense():
    if request.method == "POST":
        expense = Expense(
            title=request.form["title"],
            amount=float(request.form["amount"]),
            category=request.form["category"],
            date=datetime.fromisoformat(request.form["date"]),
            user_id=current_user.id
        )

        db.session.add(expense)
        db.session.commit()

        flash("Expense added successfully", "success")
        return redirect(url_for("dashboard"))

    return render_template("add_expense.html")

# -------------------------------------------------
# SET MONTHLY BUDGET
# -------------------------------------------------
@app.route("/set-budget", methods=["POST"])
@login_required
def set_budget():
    current_user.monthly_budget = float(request.form["budget"])
    db.session.commit()
    flash("Monthly budget updated", "success")
    return redirect(url_for("dashboard"))

# -------------------------------------------------
# RUN APP
# -------------------------------------------------
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
